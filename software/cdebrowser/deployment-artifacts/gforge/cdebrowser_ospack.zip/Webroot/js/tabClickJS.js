<!--
function redirect(tabNum)
{
  parent.banner.document.location.href="controller.jsp?req_type=banner&tabSelected="+tabNum;
  parent.content.document.location.href="controller.jsp?req_type=change_content&tabSelected="+tabNum;
}
//-->
