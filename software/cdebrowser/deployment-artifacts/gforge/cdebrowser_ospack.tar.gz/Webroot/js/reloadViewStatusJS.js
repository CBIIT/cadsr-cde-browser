<!--
function showStatus()
{
  parent.location="controller.jsp?req_type=change_content&tabSelected=1";
}
function showBedCount()
{
 location="controller.jsp?req_type=change_content&tabSelected=2";
// parent.content.document.location.href= "controller.jsp?req_type=change_content&tabSelected=2";

}

//-->
